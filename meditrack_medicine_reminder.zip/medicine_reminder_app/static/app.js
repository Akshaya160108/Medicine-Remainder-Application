async function updateDose(medicineId, time, status, button) {
  if (button) button.disabled = true;
  try {
    const res = await fetch("/dose/action", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({medicine_id: medicineId, time, status})
    });
    const data = await res.json();
    if (!res.ok || !data.ok) throw new Error(data.error || "Unable to update dose");
    window.location.reload();
  } catch (err) {
    alert(err.message);
    if (button) button.disabled = false;
  }
}

function urlBase64ToUint8Array(base64String) {
  const padding = "=".repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const raw = window.atob(base64);
  return Uint8Array.from([...raw].map(c => c.charCodeAt(0)));
}

document.addEventListener("DOMContentLoaded", () => {
  if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(console.error);
  const btn = document.getElementById("enablePush");
  if (!btn) return;
  btn.addEventListener("click", async () => {
    try {
      if (!window.MEDI_PUBLIC_KEY) throw new Error("Push notifications are not configured by the app administrator yet.");
      if (!("PushManager" in window)) throw new Error("Push notifications are not supported by this browser.");
      const permission = await Notification.requestPermission();
      if (permission !== "granted") throw new Error("Please allow notifications in your browser settings.");
      const registration = await navigator.serviceWorker.ready;
      let subscription = await registration.pushManager.getSubscription();
      if (!subscription) subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(window.MEDI_PUBLIC_KEY)
      });
      const response = await fetch("/push/subscribe", {
        method:"POST", headers:{"Content-Type":"application/json"},
        body:JSON.stringify(subscription)
      });
      if (!response.ok) throw new Error("Could not save this device. Please try again.");
      btn.textContent = "✓ Notifications enabled";
      alert("Notifications enabled on this device.");
    } catch (e) { alert(e.message); }
  });
});
