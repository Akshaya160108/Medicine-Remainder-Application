self.addEventListener("push", event => {
  let data = {title:"Medicine reminder", body:"It's time for your scheduled medicine."};
  try { if (event.data) data = {...data, ...event.data.json()}; } catch(e) {}
  event.waitUntil(self.registration.showNotification(data.title, {
    body: data.body, icon: "/static/icon-192.png", badge: "/static/icon-192.png",
    tag: "medicine-reminder", renotify: true, data: {url:"/dashboard"}
  }));
});
self.addEventListener("notificationclick", event => {
  event.notification.close();
  event.waitUntil(clients.matchAll({type:"window", includeUncontrolled:true}).then(list => {
    for (const client of list) if ("focus" in client) return client.focus();
    return clients.openWindow(event.notification.data.url || "/dashboard");
  }));
});
