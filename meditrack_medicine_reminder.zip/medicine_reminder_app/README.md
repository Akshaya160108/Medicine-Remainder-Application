# MediTrack — Medicine Reminder Web App

A mobile-friendly Python/Flask + SQLite medicine schedule tracker with individual accounts, daily dose status, history, and optional browser push notifications.

## Features
- Individual username/password accounts (passwords are hashed).
- Add a medicine, dosage, start date, number of days, one or more daily times, and notes.
- Today's Upcoming, Completed, and Skipped lists.
- Mark a dose as taken or skipped; status is stored per user, medicine, date, and time.
- Dose history.
- Installable PWA shell and browser push notifications when configured.
- Responsive layout for mobile and desktop.

## 1. Install and run locally

Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
copy .env.example .env
# macOS/Linux: cp .env.example .env
python app.py
```

Open http://127.0.0.1:5000

The SQLite database (`medicine.db`) is created automatically.

## 2. Enable mobile push notifications

Push notifications require HTTPS (localhost is permitted for local development), a supported browser, permission from the user, and VAPID keys.

Generate VAPID keys:

```bash
python -c "from py_vapid import Vapid; v=Vapid(); v.generate_keys(); print('PUBLIC:', v.public_key); print('PRIVATE:', v.private_key)"
```

Copy the generated values into `.env`:

```env
VAPID_PUBLIC_KEY=your_public_key
VAPID_PRIVATE_KEY=your_private_key
VAPID_EMAIL=mailto:you@example.com
```

Restart the server. Sign in on the phone and tap **Enable mobile notifications**. On Android, Chrome is generally suitable; on iPhone, add the site to the Home Screen and use a supported iOS version/browser for web push. The site must be deployed over HTTPS for real devices.

The scheduler checks every 30 seconds. Keep the server process running. A server restart or downtime can mean a reminder is not delivered at its exact time. For production, use a persistent always-on host and a separate worker/scheduler process.

## 3. Deploy

Deploy to a Python host that supports persistent processes and HTTPS. Set the environment variables from `.env.example`. A typical start command is:

```bash
gunicorn -w 1 -b 0.0.0.0:$PORT app:app
```

Important:
- Use one app worker for this starter version because the scheduler is started inside the app process. For multiple workers, move scheduling to a dedicated worker to avoid duplicate sends.
- Persist the SQLite file or switch to PostgreSQL for a multi-instance production deployment.
- Set a strong random `SECRET_KEY`.
- Back up the database.
- Do not commit `.env` or private VAPID keys to Git.
- Use HTTPS.

## Safety and scope

This is a personal reminder and logging tool, not a medical decision system. It does not recommend medicines, calculate doses, or advise what to do after a missed dose. Enter medicine instructions and schedules as prescribed by a qualified healthcare professional. Users should follow their clinician/pharmacist's advice if a dose is missed or a schedule changes.

## Known starter limitations

- Reminders are sent when the server scheduler is running and a due time matches the server's local timezone.
- This starter checks exact minute matches every 30 seconds; it does not queue reminders missed during server downtime.
- Push notifications depend on browser/device support and user permission. Email/SMS reminders are not included.
- Password reset, email verification, caregiver accounts, and audit-grade medical records are not included.
