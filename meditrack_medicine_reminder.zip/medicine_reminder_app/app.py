import os, json, sqlite3
from datetime import date, datetime, timedelta
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session, send_from_directory, make_response
from werkzeug.security import generate_password_hash, check_password_hash
from apscheduler.schedulers.background import BackgroundScheduler
from dotenv import load_dotenv

load_dotenv()
app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "change-this-secret-before-deployment")
DB_PATH = os.getenv("DATABASE_PATH", "medicine.db")
VAPID_PUBLIC_KEY = os.getenv("VAPID_PUBLIC_KEY", "")
VAPID_PRIVATE_KEY = os.getenv("VAPID_PRIVATE_KEY", "")
VAPID_EMAIL = os.getenv("VAPID_EMAIL", "mailto:admin@example.com")

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    with db() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS medicines (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            name TEXT NOT NULL,
            dosage TEXT NOT NULL,
            start_date TEXT NOT NULL,
            end_date TEXT NOT NULL,
            times TEXT NOT NULL,
            instructions TEXT DEFAULT '',
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS dose_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            medicine_id INTEGER NOT NULL REFERENCES medicines(id) ON DELETE CASCADE,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            scheduled_date TEXT NOT NULL,
            scheduled_time TEXT NOT NULL,
            status TEXT NOT NULL CHECK(status IN ('taken','skipped')),
            action_time TEXT NOT NULL,
            UNIQUE(medicine_id, scheduled_date, scheduled_time)
        );
        CREATE TABLE IF NOT EXISTS push_subscriptions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            subscription_json TEXT NOT NULL,
            UNIQUE(user_id, subscription_json)
        );
        CREATE TABLE IF NOT EXISTS sent_notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            medicine_id INTEGER NOT NULL REFERENCES medicines(id) ON DELETE CASCADE,
            scheduled_date TEXT NOT NULL,
            scheduled_time TEXT NOT NULL,
            sent_at TEXT NOT NULL,
            UNIQUE(medicine_id, scheduled_date, scheduled_time)
        );
        """)

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

def parse_times(raw):
    vals = []
    for part in raw.split(","):
        part = part.strip()
        if not part:
            continue
        try:
            datetime.strptime(part, "%H:%M")
        except ValueError:
            raise ValueError("Enter times in 24-hour HH:MM format, separated by commas.")
        if part not in vals:
            vals.append(part)
    if not vals:
        raise ValueError("Add at least one reminder time.")
    return sorted(vals)

@app.route("/sw.js")
def service_worker():
    response = make_response(send_from_directory("static", "sw.js"))
    response.headers["Service-Worker-Allowed"] = "/"
    response.headers["Content-Type"] = "application/javascript"
    return response

@app.route("/")
def index():
    if "user_id" not in session:
        return redirect(url_for("login"))
    return redirect(url_for("dashboard"))

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if len(username) < 3 or len(password) < 8:
            flash("Username must be at least 3 characters and password at least 8 characters.", "error")
        else:
            try:
                with db() as con:
                    cur = con.execute(
                        "INSERT INTO users(username,password_hash,created_at) VALUES(?,?,?)",
                        (username, generate_password_hash(password), datetime.now().isoformat(timespec="seconds"))
                    )
                    session["user_id"] = cur.lastrowid
                    session["username"] = username
                return redirect(url_for("dashboard"))
            except sqlite3.IntegrityError:
                flash("That username is already taken. Please choose another.", "error")
    return render_template("auth.html", mode="register")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        with db() as con:
            user = con.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            return redirect(url_for("dashboard"))
        flash("Incorrect username or password.", "error")
    return render_template("auth.html", mode="login")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

def get_today_items(user_id):
    today = date.today().isoformat()
    with db() as con:
        meds = con.execute("""
            SELECT * FROM medicines
            WHERE user_id=? AND start_date<=? AND end_date>=?
            ORDER BY name COLLATE NOCASE
        """, (user_id, today, today)).fetchall()
        logs = con.execute("""
            SELECT * FROM dose_logs WHERE user_id=? AND scheduled_date=?
        """, (user_id, today)).fetchall()
    log_map = {(x["medicine_id"], x["scheduled_time"]): x for x in logs}
    upcoming, completed, skipped = [], [], []
    now_hm = datetime.now().strftime("%H:%M")
    for med in meds:
        for t in json.loads(med["times"]):
            log = log_map.get((med["id"], t))
            item = dict(med)
            item["scheduled_time"] = t
            item["key"] = f'{med["id"]}|{t}'
            item["status"] = log["status"] if log else ("due" if t <= now_hm else "upcoming")
            if log and log["status"] == "taken":
                completed.append(item)
            elif log and log["status"] == "skipped":
                skipped.append(item)
            else:
                upcoming.append(item)
    upcoming.sort(key=lambda x: (x["scheduled_time"], x["name"].lower()))
    completed.sort(key=lambda x: (x["scheduled_time"], x["name"].lower()))
    skipped.sort(key=lambda x: (x["scheduled_time"], x["name"].lower()))
    return upcoming, completed, skipped

@app.route("/dashboard")
@login_required
def dashboard():
    upcoming, completed, skipped = get_today_items(session["user_id"])
    with db() as con:
        total_meds = con.execute(
            "SELECT COUNT(*) FROM medicines WHERE user_id=? AND end_date>=?",
            (session["user_id"], date.today().isoformat())
        ).fetchone()[0]
    return render_template("dashboard.html", upcoming=upcoming, completed=completed,
                           skipped=skipped, total_meds=total_meds,
                           public_key=VAPID_PUBLIC_KEY, today=date.today().strftime("%A, %d %B %Y"),
                           today_iso=date.today().isoformat())

@app.route("/medicines/add", methods=["POST"])
@login_required
def add_medicine():
    name = request.form.get("name", "").strip()
    dosage = request.form.get("dosage", "").strip()
    start = request.form.get("start_date", "")
    days = request.form.get("days", "")
    instructions = request.form.get("instructions", "").strip()
    try:
        times = parse_times(request.form.get("times", ""))
        start_date = date.fromisoformat(start)
        duration = int(days)
        if not name or not dosage or duration < 1 or duration > 3650:
            raise ValueError("Please enter valid medicine details and a duration from 1 to 3650 days.")
        end_date = start_date + timedelta(days=duration - 1)
        with db() as con:
            con.execute("""
                INSERT INTO medicines(user_id,name,dosage,start_date,end_date,times,instructions,created_at)
                VALUES(?,?,?,?,?,?,?,?)
            """, (session["user_id"], name, dosage, start_date.isoformat(), end_date.isoformat(),
                  json.dumps(times), instructions, datetime.now().isoformat(timespec="seconds")))
        flash("Medicine schedule added successfully.", "success")
    except (ValueError, TypeError):
        flash("Please check the dates, duration and reminder times. Times must look like 08:00, 14:00.", "error")
    return redirect(url_for("dashboard"))

@app.route("/medicines/<int:medicine_id>/delete", methods=["POST"])
@login_required
def delete_medicine(medicine_id):
    with db() as con:
        con.execute("DELETE FROM medicines WHERE id=? AND user_id=?", (medicine_id, session["user_id"]))
    flash("Medicine schedule removed.", "success")
    return redirect(url_for("dashboard"))

@app.route("/dose/action", methods=["POST"])
@login_required
def dose_action():
    data = request.get_json(silent=True) or {}
    try:
        medicine_id = int(data.get("medicine_id"))
        scheduled_time = data.get("time", "")
        status = data.get("status", "")
        datetime.strptime(scheduled_time, "%H:%M")
        if status not in ("taken", "skipped"):
            raise ValueError()
        today = date.today().isoformat()
        with db() as con:
            med = con.execute("SELECT id FROM medicines WHERE id=? AND user_id=? AND start_date<=? AND end_date>=?",
                              (medicine_id, session["user_id"], today, today)).fetchone()
            if not med:
                return jsonify(ok=False, error="Medicine not found or not active today."), 404
            con.execute("""
                INSERT INTO dose_logs(medicine_id,user_id,scheduled_date,scheduled_time,status,action_time)
                VALUES(?,?,?,?,?,?)
                ON CONFLICT(medicine_id,scheduled_date,scheduled_time)
                DO UPDATE SET status=excluded.status, action_time=excluded.action_time
            """, (medicine_id, session["user_id"], today, scheduled_time, status,
                  datetime.now().isoformat(timespec="seconds")))
        return jsonify(ok=True)
    except Exception:
        return jsonify(ok=False, error="Could not update this dose."), 400

@app.route("/history")
@login_required
def history():
    with db() as con:
        rows = con.execute("""
            SELECT l.*, m.name, m.dosage FROM dose_logs l
            JOIN medicines m ON m.id=l.medicine_id
            WHERE l.user_id=? ORDER BY l.scheduled_date DESC, l.scheduled_time DESC LIMIT 150
        """, (session["user_id"],)).fetchall()
    return render_template("history.html", rows=rows)

@app.route("/push/subscribe", methods=["POST"])
@login_required
def push_subscribe():
    sub = request.get_json(silent=True)
    if not sub or "endpoint" not in sub:
        return jsonify(ok=False), 400
    with db() as con:
        con.execute("INSERT OR IGNORE INTO push_subscriptions(user_id,subscription_json) VALUES(?,?)",
                    (session["user_id"], json.dumps(sub)))
    return jsonify(ok=True)

def send_due_notifications():
    if not VAPID_PRIVATE_KEY or not VAPID_PUBLIC_KEY:
        return
    try:
        from pywebpush import webpush, WebPushException
    except ImportError:
        return
    now = datetime.now()
    today, hm = now.date().isoformat(), now.strftime("%H:%M")
    with db() as con:
        due = con.execute("""
            SELECT m.id,m.user_id,m.name,m.dosage,m.times
            FROM medicines m WHERE m.start_date<=? AND m.end_date>=?
        """, (today, today)).fetchall()
        for med in due:
            if hm not in json.loads(med["times"]):
                continue
            already_logged = con.execute("""
                SELECT 1 FROM dose_logs WHERE medicine_id=? AND scheduled_date=? AND scheduled_time=?
            """, (med["id"], today, hm)).fetchone()
            already_sent = con.execute("""
                SELECT 1 FROM sent_notifications WHERE medicine_id=? AND scheduled_date=? AND scheduled_time=?
            """, (med["id"], today, hm)).fetchone()
            if already_logged or already_sent:
                continue
            subs = con.execute("SELECT id,subscription_json FROM push_subscriptions WHERE user_id=?",
                               (med["user_id"],)).fetchall()
            if not subs:
                continue
            payload = json.dumps({"title": "Medicine reminder", "body": f'Time to take {med["name"]} ({med["dosage"]}).'})
            sent_any = False
            for sub in subs:
                try:
                    webpush(subscription_info=json.loads(sub["subscription_json"]), data=payload,
                            vapid_private_key=VAPID_PRIVATE_KEY,
                            vapid_claims={"sub": VAPID_EMAIL})
                    sent_any = True
                except Exception:
                    # An expired subscription should not prevent delivery to another device.
                    pass
            if sent_any:
                con.execute("INSERT OR IGNORE INTO sent_notifications(medicine_id,scheduled_date,scheduled_time,sent_at) VALUES(?,?,?,?)",
                            (med["id"], today, hm, datetime.now().isoformat(timespec="seconds")))

init_db()
scheduler = BackgroundScheduler(daemon=True)
scheduler.add_job(send_due_notifications, "interval", seconds=30, id="medicine_push", max_instances=1)
scheduler.start()

if __name__ == "__main__":
    app.run(debug=True, use_reloader=False, host="0.0.0.0", port=int(os.getenv("PORT", 5000)))
